# Receipt extraction schema (v1.0)

Contents:
1. Design principles
2. Top-level shape
3. `document`
4. `merchant`
5. `transaction`
6. `amounts`
7. `currency_conversion`
8. `line_items`
9. `attendees`
10. `payment`
11. `derived`
12. `extraction`
13. Enum reference
14. Normalisation rules (money, dates, quantities)

---

## 1. Design principles

The schema is **policy-agnostic**: it holds facts, never verdicts. It is shaped so that
common expense rules can be evaluated from it by a separate step without going back to
the image — per-item limits (`line_items[].line_total`), per-person limits
(`derived.amount_per_person`), alcohol caps (`derived.alcohol_share_of_total_percent`),
claim deadlines (`transaction.date`), currency rules (`amounts.currency`,
`currency_conversion`), purchase-order requirements
(`transaction.purchase_order_number`), itemisation requirements
(`document.is_itemised`), and category exclusions (`line_items[].category_hint`).

Three conventions matter everywhere:

- `null` = not stated / not readable. `0` = printed as zero. Never swap the two.
- `*_raw` fields hold the printed string, unmodified, next to the normalised value.
- Every field is present in the output even when `null`; arrays are `[]` when empty.
  A stable shape means downstream code can address fields without existence checks.

---

## 2. Top-level shape

A single receipt is one object. Several receipts from one input become a JSON array of
such objects.

```json
{
  "schema_version": "1.0",
  "document": { },
  "merchant": { },
  "transaction": { },
  "amounts": { },
  "currency_conversion": { },
  "line_items": [ ],
  "attendees": { },
  "payment": { },
  "derived": { },
  "extraction": { }
}
```

`schema_version` is the string `"1.0"`.

---

## 3. `document`

| field | type | notes |
|---|---|---|
| `source_file` | string | File name or path of the input. |
| `document_type` | enum | `receipt`, `invoice`, `credit_note`, `bill`, `ticket`, `statement`, `other`, `unknown`. A card statement is not a receipt — label it honestly, since many policies reject statements. |
| `document_subtype` | string\|null | Free text such as `restaurant_bill`, `hotel_folio`, `taxi`, `online_order`. |
| `is_itemised` | bool\|null | `true` when individual goods/services with amounts are listed, not just a total. |
| `is_original` | bool\|null | `false` for a visible `COPY`/`DUPLICATE` mark; `null` when nothing indicates either way. |
| `page_count` | int\|null | Pages of the source document. |
| `legibility` | enum | `clear`, `partial`, `poor`. Drives how much a reviewer should trust the rest. |
| `language` | string\|null | ISO 639-1 code of the document text, e.g. `en`, `de`. |
| `related_documents` | array of string | Identifiers of sibling documents (e.g. the invoice a credit note refers to). |

---

## 4. `merchant`

| field | type | notes |
|---|---|---|
| `name` | string\|null | Trading name as printed. |
| `legal_name` | string\|null | Only if separately printed (e.g. `… GmbH`). |
| `category_hint` | enum | `restaurant`, `cafe`, `bar`, `hotel`, `airline`, `rail`, `taxi_rideshare`, `fuel`, `retail`, `electronics`, `grocery`, `professional_services`, `software_subscription`, `sporting_goods`, `pharmacy`, `other`, `unknown`. Descriptive only. |
| `address` | object | `{ "street", "city", "region", "postal_code", "country", "country_code", "full_text" }`, all string\|null; `country_code` is ISO 3166-1 alpha-2. |
| `phone` | string\|null | As printed. |
| `website` | string\|null | |
| `email` | string\|null | |
| `tax_id` | string\|null | VAT / USt-IdNr / TIN, whichever is printed. |
| `registration_id` | string\|null | Company or trade-register number. |
| `store_id` | string\|null | Branch/store/terminal identifier. |

---

## 5. `transaction`

| field | type | notes |
|---|---|---|
| `receipt_number` | string\|null | The document's own number (`RECEIPT: BR-2547` → `BR-2547`). |
| `invoice_number` | string\|null | |
| `order_reference` | string\|null | Web/order/booking reference. |
| `purchase_order_number` | string\|null | Contains only a genuine PO/`Bestellnummer` reference. Never copy an invoice or order number here — PO presence is decisive in many rules. |
| `date` | string\|null | `YYYY-MM-DD`. |
| `date_raw` | string\|null | Printed date string. |
| `date_is_ambiguous` | bool | `true` when day/month order could not be resolved with certainty. |
| `time` | string\|null | `HH:MM`, 24-hour. |
| `time_raw` | string\|null | Printed time string, including junk like `INVALID DATE`. |
| `datetime_iso` | string\|null | `YYYY-MM-DDTHH:MM` when both parts exist. |
| `timezone` | string\|null | Only when printed. |
| `service_period` | object | `{ "start_date", "end_date" }` (string\|null, `YYYY-MM-DD`) for stays/subscriptions covering a span. |
| `table_or_location` | string\|null | Table number, room, seat, pump. |
| `server` | string\|null | Server/cashier name as printed. |
| `guest_count` | int\|null | Number of covers/guests printed on the bill. Distinct from `attendees.count`, which is what a human documents later. |

---

## 6. `amounts`

All monetary fields are numbers or `null`, expressed in `currency`.

| field | type | notes |
|---|---|---|
| `currency` | string\|null | ISO 4217, e.g. `EUR`. |
| `currency_symbol_raw` | string\|null | `€`, `$`, `CHF` as printed. |
| `currency_inferred` | bool | `true` when the code was deduced rather than printed. |
| `subtotal` | number\|null | Net/pre-tax or pre-service total as printed. |
| `tax_total` | number\|null | Sum of tax lines. |
| `taxes` | array | Objects `{ "label": string\|null, "rate_percent": number\|null, "base_amount": number\|null, "amount": number\|null }`, one per printed tax line. |
| `tip` | number\|null | Gratuity. Note: a line saying *"tip is not included"* means `null`, not `0` — nothing was charged and nothing was recorded. |
| `service_charge` | number\|null | Mandatory service, distinct from tip. |
| `discount_total` | number\|null | Positive number representing the reduction. |
| `shipping` | number\|null | |
| `deposit_or_prepayment` | number\|null | Amount already paid in advance. |
| `rounding` | number\|null | Cash-rounding adjustment. |
| `total` | number\|null | Grand total charged — the primary figure for limit checks. |
| `amount_due` | number\|null | Remaining balance if different from `total`. |
| `amount_paid` | number\|null | What the payment block shows as taken. |
| `total_raw` | string\|null | Printed grand-total string, e.g. `€57.78`. |
| `totals_reconcile` | bool\|null | `true` when line items and totals are arithmetically consistent within 0.02; `false` when they are not; `null` when there isn't enough on the document to tell. |
| `reconciliation_note` | string\|null | Required (non-null) when `totals_reconcile` is `false`: state the discrepancy in figures. |

---

## 7. `currency_conversion`

Present always; all fields `null` when the receipt is already in the reporting currency.

| field | type | notes |
|---|---|---|
| `is_foreign_currency` | bool\|null | `true` when `amounts.currency` differs from the reporting currency the user names. Leave `null` when no reporting currency was given. |
| `reporting_currency` | string\|null | Only if the user or document states one. |
| `exchange_rate` | number\|null | Units of reporting currency per 1 unit of `amounts.currency`; only if printed on the document or supplied by the user. Never look one up and never estimate. |
| `exchange_rate_source` | string\|null | E.g. `printed on receipt`, `ECB 2026-09-16`. |
| `exchange_rate_date` | string\|null | `YYYY-MM-DD`. |
| `converted_total` | number\|null | `total × exchange_rate`, only when a rate is genuinely available. |

---

## 8. `line_items`

One object per printed line. Keep the printed order.

| field | type | notes |
|---|---|---|
| `line_number` | int | 1-based, in printed order. |
| `description` | string | Exactly as printed, including any `2 x` prefix or `@ €12.00` suffix. |
| `description_normalized` | string\|null | Human-readable cleanup (`"2 CAESAR SALAD @ €12.00"` → `"Caesar salad"`). |
| `quantity` | number\|null | `1` when a single unit is implied; `null` only if truly unknowable. |
| `unit` | string\|null | `item`, `night`, `km`, `hour`, `kg` … when printed. |
| `unit_price` | number\|null | Per-unit price; `null` when neither printed nor exactly derivable. |
| `line_total` | number\|null | Amount for the line. This is what per-item limits are checked against. |
| `discount` | number\|null | Line-level reduction as a positive number. |
| `tax_rate_percent` | number\|null | When shown per line. |
| `category_hint` | enum | See §13. Descriptive label, never a verdict. |
| `is_alcohol` | bool\|null | `true` for wine, beer, spirits, champagne, cocktails, aperitifs, liqueurs. `null` only when the description is unreadable. |
| `is_food_or_beverage` | bool\|null | Broader flag covering food and all drinks. |
| `product_code` | string\|null | SKU / article number when printed. |
| `notes` | string\|null | Anything a reviewer should know about this line (e.g. `"handwritten"`). |

---

## 9. `attendees`

Meal and entertainment rules frequently turn on who was present. Only record what the
document or the user states.

| field | type | notes |
|---|---|---|
| `count` | int\|null | Documented attendee count. Falls back to `transaction.guest_count` **only** if the user confirms they are the same — otherwise leave `null`. |
| `names` | array of string | Names as documented; `[]` when none. |
| `business_purpose` | string\|null | Stated purpose, verbatim where possible. |
| `source` | enum | `receipt`, `user_provided`, `not_documented`. Makes clear whether the evidence is on paper. |

---

## 10. `payment`

| field | type | notes |
|---|---|---|
| `method` | enum | `card`, `cash`, `bank_transfer`, `invoice_open`, `mobile_wallet`, `voucher`, `company_card`, `other`, `unknown`. |
| `card_brand` | string\|null | `MASTERCARD`, `VISA`, … |
| `card_last4` | string\|null | Last four digits only. Never record a fuller card number even if printed — extra digits are payment data with no policy value. |
| `entry_mode` | string\|null | `CONTACTLESS`, `CHIP`, `SWIPE`, `ONLINE`. |
| `authorization_status` | string\|null | `APPROVED`, `DECLINED`, as printed. |
| `transaction_reference` | string\|null | Acquirer/auth reference. |
| `paid_by` | string\|null | Cardholder or payer name when printed. |

---

## 11. `derived`

Deterministic arithmetic over extracted values — no thresholds, no rules. Every field
is `null` when its inputs are missing, and must reconcile with the rest of the object
(the validator recomputes them).

| field | type | definition |
|---|---|---|
| `item_count` | int | Number of entries in `line_items`. |
| `line_items_sum` | number\|null | Sum of non-null `line_total` values. |
| `alcohol_total` | number\|null | Sum of `line_total` where `is_alcohol` is `true`; `0` when items exist and none are alcohol. |
| `non_alcohol_total` | number\|null | `line_items_sum − alcohol_total`. |
| `alcohol_share_of_total_percent` | number\|null | `alcohol_total / total × 100`, rounded to 2 decimals. Uses `amounts.total`; enables percentage caps without re-reading the receipt. |
| `amount_per_person` | number\|null | `total / (attendees.count or transaction.guest_count)`, rounded to 2 decimals. `null` when no count exists. |
| `person_count_used` | int\|null | Which count fed `amount_per_person`. |
| `largest_line_total` | number\|null | Max `line_total`; supports per-item limits. |
| `days_since_transaction` | int\|null | Whole days between `transaction.date` and the date part of `extraction.extracted_at`. Supports deadline rules; it is a date difference, not a judgement. Negative when the printed date is in the future — keep the negative value and add a warning rather than "correcting" the date. |

---

## 12. `extraction`

| field | type | notes |
|---|---|---|
| `extracted_at` | string | ISO 8601 timestamp of the extraction run. |
| `extractor` | string\|null | Model/tool identifier. |
| `source_modality` | enum | `image`, `pdf_text`, `pdf_render`, `text`, `mixed`. |
| `overall_confidence` | enum | `high`, `medium`, `low`. |
| `fields_low_confidence` | array of string | Dotted paths, e.g. `amounts.tax_total`, `line_items[2].unit_price`. |
| `unreadable_regions` | array of string | Plain description of what could not be read. |
| `warnings` | array of string | Anomalies: failed arithmetic, junk values, `COPY` stamps, missing tax lines. |
| `assumptions` | array of string | Every inference you made (currency inferred from country, date order chosen, quantity defaulted to 1). Anything not literally printed belongs here so a reviewer can audit it. |

---

## 13. Enum reference

`document.document_type`: `receipt`, `invoice`, `credit_note`, `bill`, `ticket`,
`statement`, `other`, `unknown`

`document.legibility`: `clear`, `partial`, `poor`

`merchant.category_hint`: `restaurant`, `cafe`, `bar`, `hotel`, `airline`, `rail`,
`taxi_rideshare`, `fuel`, `retail`, `electronics`, `grocery`,
`professional_services`, `software_subscription`, `sporting_goods`, `pharmacy`,
`other`, `unknown`

`line_items[].category_hint`: `food_beverage`, `alcohol`, `accommodation`,
`transport`, `fuel`, `it_equipment`, `it_accessory`, `software_subscription`,
`office_supplies`, `professional_services`, `training`, `telecom`, `shipping`,
`fee_or_charge`, `tax`, `tip`, `personal_or_leisure`, `clothing`, `entertainment`,
`other`, `unknown`

`attendees.source`: `receipt`, `user_provided`, `not_documented`

`payment.method`: `card`, `cash`, `bank_transfer`, `invoice_open`, `mobile_wallet`,
`voucher`, `company_card`, `other`, `unknown`

`extraction.source_modality`: `image`, `pdf_text`, `pdf_render`, `text`, `mixed`

`extraction.overall_confidence`: `high`, `medium`, `low`

---

## 14. Normalisation rules

**Money.** Always a JSON number with the document's own precision, no symbols, no
thousands separators. Continental format `1.234,56` → `1234.56`; Anglo `1,234.56` →
`1234.56`. A trailing `-` or parentheses means negative. Discounts are stored as
positive numbers in discount fields, so the sign convention is unambiguous.

**Currency.** Prefer a printed ISO code, then an unambiguous symbol (`€`→`EUR`,
`£`→`GBP`, `¥`→`JPY`). `$` is ambiguous: resolve it via the address country and set
`currency_inferred` to `true` with an assumption recorded. If it cannot be resolved,
leave `currency` `null` rather than guessing `USD`.

**Dates.** Output `YYYY-MM-DD`. Two-digit years: `26` → `2026` when it keeps the date
within roughly a year of today, otherwise record ambiguity. Month names in any
language resolve normally. Dotted European dates (`16.9.2026`) are day-first. Slash
dates are ambiguous unless the day exceeds 12 or the merchant country settles it —
then set `date_is_ambiguous`, choose the country-consistent reading, and log the
assumption.

**Times.** 24-hour `HH:MM`. `8:15 PM` → `20:15`. Non-time strings such as
`INVALID DATE` go in `time_raw` with `time` left `null` and a warning added.

**Quantities.** `2 x`, `2 @`, `2 CAESAR SALAD @ €12.00` all give `quantity: 2`. Weight
or distance lines keep their unit (`0.482 kg`, `12.4 km`). When quantity is absent,
default to `1` and record the assumption — but only when the line clearly represents a
single purchase.

**Reconciliation.** Check, in this order, tolerating rounding of 0.02:
1. `Σ line_total` ≈ `subtotal` (or ≈ `total` when no subtotal is printed);
2. `subtotal + tax_total + tip + service_charge + shipping − discount_total + rounding`
   ≈ `total`.
Set `totals_reconcile` accordingly and, when `false`, write the discrepancy into
`reconciliation_note` and a warning. Note that some receipts print a
tax-inclusive subtotal, in which case check 2 will fail legitimately — say so in the
note rather than altering any figure.
