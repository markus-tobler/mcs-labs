#!/usr/bin/env python3
"""Validate receipt-extraction JSON against schema v1.0 (see references/schema.md).

Stdlib only - no installs required.

Usage:
    python validate_receipt_json.py output.json
    python validate_receipt_json.py output.json --quiet     # only problems
    python validate_receipt_json.py output.json --json      # machine-readable report

Exit code 0 = valid (errors == 0), 1 = invalid, 2 = could not read input.

The validator checks three things:
  1. structure - every block/field present, correct type, allowed enum value
  2. formats   - ISO dates (YYYY-MM-DD), times (HH:MM), ISO-4217-shaped currency
  3. arithmetic - derived values recomputed, totals reconciled, per-person and
     alcohol share consistent with the extracted numbers

Warnings are advisory (they do not fail the run); errors do.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import date, datetime

SCHEMA_VERSION = "1.0"
TOL = 0.02  # rounding tolerance in currency units

DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
TIME_RE = re.compile(r"^\d{2}:\d{2}$")
DATETIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?$")
CURRENCY_RE = re.compile(r"^[A-Z]{3}$")
COUNTRY_RE = re.compile(r"^[A-Z]{2}$")

STR = "str"
NUM = "num"
INT = "int"
BOOL = "bool"
ARR_STR = "arr_str"

ENUMS = {
    "document_type": ["receipt", "invoice", "credit_note", "bill", "ticket",
                      "statement", "other", "unknown"],
    "legibility": ["clear", "partial", "poor"],
    "merchant_category": ["restaurant", "cafe", "bar", "hotel", "airline", "rail",
                          "taxi_rideshare", "fuel", "retail", "electronics", "grocery",
                          "professional_services", "software_subscription",
                          "sporting_goods", "pharmacy", "other", "unknown"],
    "item_category": ["food_beverage", "alcohol", "accommodation", "transport", "fuel",
                      "it_equipment", "it_accessory", "software_subscription",
                      "office_supplies", "professional_services", "training", "telecom",
                      "shipping", "fee_or_charge", "tax", "tip", "personal_or_leisure",
                      "clothing", "entertainment", "other", "unknown"],
    "attendee_source": ["receipt", "user_provided", "not_documented"],
    "payment_method": ["card", "cash", "bank_transfer", "invoice_open", "mobile_wallet",
                       "voucher", "company_card", "other", "unknown"],
    "source_modality": ["image", "pdf_text", "pdf_render", "text", "mixed"],
    "confidence": ["high", "medium", "low"],
}

# block -> {field: (type, nullable, enum_key_or_None)}
SPEC = {
    "document": {
        "source_file": (STR, True, None),
        "document_type": (STR, False, "document_type"),
        "document_subtype": (STR, True, None),
        "is_itemised": (BOOL, True, None),
        "is_original": (BOOL, True, None),
        "page_count": (INT, True, None),
        "legibility": (STR, False, "legibility"),
        "language": (STR, True, None),
        "related_documents": (ARR_STR, False, None),
    },
    "merchant": {
        "name": (STR, True, None),
        "legal_name": (STR, True, None),
        "category_hint": (STR, False, "merchant_category"),
        "phone": (STR, True, None),
        "website": (STR, True, None),
        "email": (STR, True, None),
        "tax_id": (STR, True, None),
        "registration_id": (STR, True, None),
        "store_id": (STR, True, None),
    },
    "transaction": {
        "receipt_number": (STR, True, None),
        "invoice_number": (STR, True, None),
        "order_reference": (STR, True, None),
        "purchase_order_number": (STR, True, None),
        "date": (STR, True, None),
        "date_raw": (STR, True, None),
        "date_is_ambiguous": (BOOL, True, None),
        "time": (STR, True, None),
        "time_raw": (STR, True, None),
        "datetime_iso": (STR, True, None),
        "timezone": (STR, True, None),
        "table_or_location": (STR, True, None),
        "server": (STR, True, None),
        "guest_count": (INT, True, None),
    },
    "amounts": {
        "currency": (STR, True, None),
        "currency_symbol_raw": (STR, True, None),
        "currency_inferred": (BOOL, True, None),
        "subtotal": (NUM, True, None),
        "tax_total": (NUM, True, None),
        "tip": (NUM, True, None),
        "service_charge": (NUM, True, None),
        "discount_total": (NUM, True, None),
        "shipping": (NUM, True, None),
        "deposit_or_prepayment": (NUM, True, None),
        "rounding": (NUM, True, None),
        "total": (NUM, True, None),
        "amount_due": (NUM, True, None),
        "amount_paid": (NUM, True, None),
        "total_raw": (STR, True, None),
        "totals_reconcile": (BOOL, True, None),
        "reconciliation_note": (STR, True, None),
    },
    "currency_conversion": {
        "is_foreign_currency": (BOOL, True, None),
        "reporting_currency": (STR, True, None),
        "exchange_rate": (NUM, True, None),
        "exchange_rate_source": (STR, True, None),
        "exchange_rate_date": (STR, True, None),
        "converted_total": (NUM, True, None),
    },
    "attendees": {
        "count": (INT, True, None),
        "business_purpose": (STR, True, None),
        "source": (STR, False, "attendee_source"),
    },
    "payment": {
        "method": (STR, False, "payment_method"),
        "card_brand": (STR, True, None),
        "card_last4": (STR, True, None),
        "entry_mode": (STR, True, None),
        "authorization_status": (STR, True, None),
        "transaction_reference": (STR, True, None),
        "paid_by": (STR, True, None),
    },
    "derived": {
        "item_count": (INT, True, None),
        "line_items_sum": (NUM, True, None),
        "alcohol_total": (NUM, True, None),
        "non_alcohol_total": (NUM, True, None),
        "alcohol_share_of_total_percent": (NUM, True, None),
        "amount_per_person": (NUM, True, None),
        "person_count_used": (INT, True, None),
        "largest_line_total": (NUM, True, None),
        "days_since_transaction": (INT, True, None),
    },
    "extraction": {
        "extracted_at": (STR, False, None),
        "extractor": (STR, True, None),
        "source_modality": (STR, False, "source_modality"),
        "overall_confidence": (STR, False, "confidence"),
        "fields_low_confidence": (ARR_STR, False, None),
        "unreadable_regions": (ARR_STR, False, None),
        "warnings": (ARR_STR, False, None),
        "assumptions": (ARR_STR, False, None),
    },
}

ITEM_SPEC = {
    "line_number": (INT, False, None),
    "description": (STR, False, None),
    "description_normalized": (STR, True, None),
    "quantity": (NUM, True, None),
    "unit": (STR, True, None),
    "unit_price": (NUM, True, None),
    "line_total": (NUM, True, None),
    "discount": (NUM, True, None),
    "tax_rate_percent": (NUM, True, None),
    "category_hint": (STR, False, "item_category"),
    "is_alcohol": (BOOL, True, None),
    "is_food_or_beverage": (BOOL, True, None),
    "product_code": (STR, True, None),
    "notes": (STR, True, None),
}

ADDRESS_FIELDS = ["street", "city", "region", "postal_code", "country",
                  "country_code", "full_text"]


class Report:
    def __init__(self):
        self.errors = []
        self.warnings = []

    def err(self, path, msg):
        self.errors.append({"path": path, "message": msg})

    def warn(self, path, msg):
        self.warnings.append({"path": path, "message": msg})


def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def check_field(rep, path, value, spec):
    kind, nullable, enum_key = spec
    if value is None:
        if not nullable:
            rep.err(path, "must not be null")
        return
    if kind == STR and not isinstance(value, str):
        rep.err(path, f"expected string, got {type(value).__name__}")
        return
    if kind == NUM and not _is_num(value):
        if isinstance(value, str):
            rep.err(path, f"expected number, got string {value!r} "
                          "(money must be numeric, no symbols)")
        else:
            rep.err(path, f"expected number, got {type(value).__name__}")
        return
    if kind == INT and not (isinstance(value, int) and not isinstance(value, bool)):
        rep.err(path, f"expected integer, got {type(value).__name__}")
        return
    if kind == BOOL and not isinstance(value, bool):
        rep.err(path, f"expected boolean, got {type(value).__name__}")
        return
    if kind == ARR_STR:
        if not isinstance(value, list):
            rep.err(path, f"expected array, got {type(value).__name__}")
            return
        for i, v in enumerate(value):
            if not isinstance(v, str):
                rep.err(f"{path}[{i}]", "expected string entry")
    if enum_key and isinstance(value, str) and value not in ENUMS[enum_key]:
        rep.err(path, f"value {value!r} not in allowed values: "
                      f"{', '.join(ENUMS[enum_key])}")


def check_block(rep, name, block, spec, prefix=""):
    if not isinstance(block, dict):
        rep.err(prefix + name, "expected object")
        return {}
    for field, fspec in spec.items():
        p = f"{prefix}{name}.{field}"
        if field not in block:
            rep.err(p, "missing (every field must be present, null when unknown)")
            continue
        check_field(rep, p, block[field], fspec)
    for field in block:
        if field not in spec and field not in ("address", "taxes", "service_period",
                                               "names"):
            rep.warn(f"{prefix}{name}.{field}", "unknown field (not in schema v1.0)")
    return block


def check_formats(rep, obj):
    tx = obj.get("transaction", {}) or {}
    for f, rx, label in (("date", DATE_RE, "YYYY-MM-DD"),
                         ("time", TIME_RE, "HH:MM (24h)"),
                         ("datetime_iso", DATETIME_RE, "YYYY-MM-DDTHH:MM")):
        v = tx.get(f)
        if isinstance(v, str) and not rx.match(v):
            rep.err(f"transaction.{f}", f"must match {label}, got {v!r}")
    if isinstance(tx.get("date"), str) and DATE_RE.match(tx["date"]):
        try:
            datetime.strptime(tx["date"], "%Y-%m-%d")
        except ValueError:
            rep.err("transaction.date", f"not a real calendar date: {tx['date']!r}")

    sp = tx.get("service_period")
    if isinstance(sp, dict):
        for f in ("start_date", "end_date"):
            v = sp.get(f)
            if isinstance(v, str) and not DATE_RE.match(v):
                rep.err(f"transaction.service_period.{f}", "must match YYYY-MM-DD")

    am = obj.get("amounts", {}) or {}
    cur = am.get("currency")
    if isinstance(cur, str) and not CURRENCY_RE.match(cur):
        rep.err("amounts.currency", f"must be a 3-letter ISO-4217 code, got {cur!r}")

    cc = obj.get("currency_conversion", {}) or {}
    for f in ("reporting_currency",):
        v = cc.get(f)
        if isinstance(v, str) and not CURRENCY_RE.match(v):
            rep.err(f"currency_conversion.{f}", "must be a 3-letter ISO-4217 code")
    if isinstance(cc.get("exchange_rate_date"), str) and \
            not DATE_RE.match(cc["exchange_rate_date"]):
        rep.err("currency_conversion.exchange_rate_date", "must match YYYY-MM-DD")

    addr = (obj.get("merchant", {}) or {}).get("address")
    if not isinstance(addr, dict):
        rep.err("merchant.address", "missing or not an object")
    else:
        for f in ADDRESS_FIELDS:
            if f not in addr:
                rep.err(f"merchant.address.{f}", "missing (use null when unknown)")
            elif addr[f] is not None and not isinstance(addr[f], str):
                rep.err(f"merchant.address.{f}", "expected string or null")
        cc2 = addr.get("country_code")
        if isinstance(cc2, str) and not COUNTRY_RE.match(cc2):
            rep.err("merchant.address.country_code",
                    "must be ISO 3166-1 alpha-2 (2 uppercase letters)")

    ext = obj.get("extraction", {}) or {}
    ea = ext.get("extracted_at")
    if isinstance(ea, str):
        try:
            datetime.fromisoformat(ea.replace("Z", "+00:00"))
        except ValueError:
            rep.err("extraction.extracted_at", f"not an ISO 8601 timestamp: {ea!r}")

    pay = obj.get("payment", {}) or {}
    l4 = pay.get("card_last4")
    if isinstance(l4, str) and not re.match(r"^\d{4}$", l4):
        rep.err("payment.card_last4",
                "must be exactly the last 4 digits (never a fuller card number)")


def check_taxes(rep, obj):
    am = obj.get("amounts", {}) or {}
    taxes = am.get("taxes")
    if not isinstance(taxes, list):
        rep.err("amounts.taxes", "missing or not an array (use [] when none)")
        return
    total_from_lines = 0.0
    seen = False
    for i, t in enumerate(taxes):
        p = f"amounts.taxes[{i}]"
        if not isinstance(t, dict):
            rep.err(p, "expected object")
            continue
        for f in ("label", "rate_percent", "base_amount", "amount"):
            if f not in t:
                rep.err(f"{p}.{f}", "missing (use null when unknown)")
        if _is_num(t.get("amount")):
            total_from_lines += float(t["amount"])
            seen = True
    if seen and _is_num(am.get("tax_total")):
        if abs(total_from_lines - float(am["tax_total"])) > TOL:
            rep.warn("amounts.tax_total",
                     f"sum of taxes[] ({round(total_from_lines, 2)}) != tax_total "
                     f"({am['tax_total']})")


def check_line_items(rep, obj):
    items = obj.get("line_items")
    if not isinstance(items, list):
        rep.err("line_items", "missing or not an array")
        return []
    for i, item in enumerate(items):
        p = f"line_items[{i}]"
        if not isinstance(item, dict):
            rep.err(p, "expected object")
            continue
        for field, fspec in ITEM_SPEC.items():
            fp = f"{p}.{field}"
            if field not in item:
                rep.err(fp, "missing (use null when unknown)")
                continue
            check_field(rep, fp, item[field], fspec)
        for field in item:
            if field not in ITEM_SPEC:
                rep.warn(f"{p}.{field}", "unknown field (not in schema v1.0)")
        if item.get("line_number") != i + 1:
            rep.warn(f"{p}.line_number",
                     f"expected {i + 1} (1-based, printed order), "
                     f"got {item.get('line_number')}")
        q, up, lt = item.get("quantity"), item.get("unit_price"), item.get("line_total")
        if _is_num(q) and _is_num(up) and _is_num(lt):
            if abs(q * up - lt) > max(TOL, abs(lt) * 0.001):
                rep.warn(f"{p}", f"quantity x unit_price ({round(q * up, 2)}) "
                                 f"!= line_total ({lt})")
        if item.get("is_alcohol") is True and item.get("is_food_or_beverage") is False:
            rep.warn(f"{p}.is_food_or_beverage",
                     "alcohol lines are beverages; expected true")
    return items


def _n(v):
    return float(v) if _is_num(v) else None


def check_derived(rep, obj):
    items = obj.get("line_items") or []
    der = obj.get("derived", {}) or {}
    am = obj.get("amounts", {}) or {}

    if isinstance(items, list) and der.get("item_count") is not None:
        if der["item_count"] != len(items):
            rep.err("derived.item_count",
                    f"expected {len(items)} (len of line_items), got {der['item_count']}")

    totals = [float(it["line_total"]) for it in items
              if isinstance(it, dict) and _is_num(it.get("line_total"))]
    if totals:
        exp_sum = round(sum(totals), 2)
        got = _n(der.get("line_items_sum"))
        if got is None:
            rep.err("derived.line_items_sum",
                    f"line totals are present; expected {exp_sum}")
        elif abs(got - exp_sum) > TOL:
            rep.err("derived.line_items_sum", f"expected {exp_sum}, got {got}")

        exp_max = round(max(totals), 2)
        got_max = _n(der.get("largest_line_total"))
        if got_max is not None and abs(got_max - exp_max) > TOL:
            rep.err("derived.largest_line_total", f"expected {exp_max}, got {got_max}")

        alc = round(sum(float(it["line_total"]) for it in items
                        if isinstance(it, dict) and it.get("is_alcohol") is True
                        and _is_num(it.get("line_total"))), 2)
        got_alc = _n(der.get("alcohol_total"))
        if got_alc is None:
            rep.err("derived.alcohol_total",
                    f"expected {alc} (0 when no alcohol lines, not null)")
        elif abs(got_alc - alc) > TOL:
            rep.err("derived.alcohol_total", f"expected {alc}, got {got_alc}")

        got_non = _n(der.get("non_alcohol_total"))
        if got_non is not None and abs(got_non - round(exp_sum - alc, 2)) > TOL:
            rep.err("derived.non_alcohol_total",
                    f"expected {round(exp_sum - alc, 2)}, got {got_non}")

        total = _n(am.get("total"))
        if total not in (None, 0):
            exp_share = round(alc / total * 100, 2)
            got_share = _n(der.get("alcohol_share_of_total_percent"))
            if got_share is None:
                rep.err("derived.alcohol_share_of_total_percent",
                        f"expected {exp_share}")
            elif abs(got_share - exp_share) > 0.05:
                rep.err("derived.alcohol_share_of_total_percent",
                        f"expected {exp_share}, got {got_share}")

    # per-person
    att = (obj.get("attendees", {}) or {}).get("count")
    guests = (obj.get("transaction", {}) or {}).get("guest_count")
    used = der.get("person_count_used")
    total = _n(am.get("total"))
    app = _n(der.get("amount_per_person"))
    if app is not None:
        if not _is_num(used) or used in (0, None):
            rep.err("derived.person_count_used",
                    "must state the count used when amount_per_person is set")
        elif total is not None:
            exp = round(total / used, 2)
            if abs(app - exp) > 0.02:
                rep.err("derived.amount_per_person",
                        f"total/{used} = {exp}, got {app}")
        if _is_num(used) and used not in (att, guests):
            rep.warn("derived.person_count_used",
                     f"{used} matches neither attendees.count ({att}) nor "
                     f"transaction.guest_count ({guests})")
    else:
        if (_is_num(att) or _is_num(guests)) and total is not None:
            rep.warn("derived.amount_per_person",
                     "a person count and a total exist; per-person amount can be computed")

    # days since transaction
    dst = der.get("days_since_transaction")
    txd = (obj.get("transaction", {}) or {}).get("date")
    ea = (obj.get("extraction", {}) or {}).get("extracted_at")
    if _is_num(dst) and isinstance(txd, str) and DATE_RE.match(txd) and isinstance(ea, str):
        try:
            d0 = datetime.strptime(txd, "%Y-%m-%d").date()
            d1 = datetime.fromisoformat(ea.replace("Z", "+00:00")).date()
            if (d1 - d0).days != dst:
                rep.err("derived.days_since_transaction",
                        f"expected {(d1 - d0).days} from transaction.date and "
                        f"extraction.extracted_at, got {dst}")
            elif dst < 0 and not (obj.get("extraction", {}) or {}).get("warnings"):
                rep.warn("derived.days_since_transaction",
                         "transaction date lies in the future relative to the "
                         "extraction time; that anomaly belongs in "
                         "extraction.warnings")
        except ValueError:
            pass


def check_reconciliation(rep, obj):
    am = obj.get("amounts", {}) or {}
    items = obj.get("line_items") or []
    totals = [float(it["line_total"]) for it in items
              if isinstance(it, dict) and _is_num(it.get("line_total"))]
    total = _n(am.get("total"))
    subtotal = _n(am.get("subtotal"))
    parts = {k: _n(am.get(k)) for k in
             ("tax_total", "tip", "service_charge", "shipping", "rounding",
              "discount_total")}

    consistent = None
    details = []
    if totals and (subtotal is not None or total is not None):
        base = subtotal if subtotal is not None else total
        s = round(sum(totals), 2)
        if abs(s - base) > TOL:
            consistent = False
            details.append(f"sum(line_total)={s} vs "
                           f"{'subtotal' if subtotal is not None else 'total'}={base}")
    if subtotal is not None and total is not None:
        built = subtotal + (parts["tax_total"] or 0) + (parts["tip"] or 0) \
            + (parts["service_charge"] or 0) + (parts["shipping"] or 0) \
            + (parts["rounding"] or 0) - (parts["discount_total"] or 0)
        if abs(built - total) > TOL:
            consistent = False
            details.append(f"subtotal+tax+tip+charges-discount={round(built, 2)} "
                           f"vs total={total}")
        elif consistent is None:
            consistent = True
    elif consistent is None and totals and total is not None:
        consistent = True

    declared = am.get("totals_reconcile")
    if consistent is None:
        if declared is True:
            rep.warn("amounts.totals_reconcile",
                     "declared true but there is not enough on the document to verify")
        return
    if declared is None:
        rep.err("amounts.totals_reconcile",
                f"computable from the extracted figures; expected {consistent}")
    elif declared != consistent:
        rep.err("amounts.totals_reconcile",
                f"declared {declared} but arithmetic says {consistent}"
                + (f" ({'; '.join(details)})" if details else ""))
    if consistent is False and not am.get("reconciliation_note"):
        rep.err("amounts.reconciliation_note",
                "required when totals do not reconcile: "
                + "; ".join(details))


def check_cross_field(rep, obj):
    att = obj.get("attendees", {}) or {}
    names = att.get("names")
    if not isinstance(names, list):
        rep.err("attendees.names", "missing or not an array (use [] when none)")
    elif any(not isinstance(n, str) for n in names):
        rep.err("attendees.names", "entries must be strings")
    if att.get("source") == "not_documented" and (att.get("count") is not None
                                                  or (names or [])):
        rep.warn("attendees.source",
                 "source is 'not_documented' but attendee data is present")

    cc = obj.get("currency_conversion", {}) or {}
    if cc.get("converted_total") is not None and cc.get("exchange_rate") is None:
        rep.err("currency_conversion.converted_total",
                "set without an exchange_rate - never estimate a conversion")
    if _is_num(cc.get("exchange_rate")) and _is_num(cc.get("converted_total")):
        total = _n((obj.get("amounts", {}) or {}).get("total"))
        if total is not None:
            exp = round(total * float(cc["exchange_rate"]), 2)
            if abs(float(cc["converted_total"]) - exp) > 0.02:
                rep.err("currency_conversion.converted_total",
                        f"total x exchange_rate = {exp}, got {cc['converted_total']}")
    if cc.get("exchange_rate") is not None and not cc.get("exchange_rate_source"):
        rep.warn("currency_conversion.exchange_rate_source",
                 "a rate without a stated source cannot be audited")

    ext = obj.get("extraction", {}) or {}
    doc = obj.get("document", {}) or {}
    if doc.get("legibility") in ("partial", "poor") and not ext.get("warnings"):
        rep.warn("extraction.warnings",
                 "legibility is not 'clear' but no warning explains what was unclear")

    am = obj.get("amounts", {}) or {}
    if am.get("currency_inferred") is True and not ext.get("assumptions"):
        rep.warn("extraction.assumptions",
                 "currency was inferred but no assumption is recorded")
    if (obj.get("transaction", {}) or {}).get("date_is_ambiguous") is True \
            and not ext.get("assumptions"):
        rep.warn("extraction.assumptions",
                 "date order was ambiguous but no assumption is recorded")

    # policy-verdict leakage: this schema must stay policy-agnostic
    banned = ("policy", "compliant", "compliance", "approved", "approval_status",
              "violation", "eligible", "eligibility", "reimbursable", "risk_score",
              "verdict", "within_limit", "rejected")
    def scan(o, path=""):
        if isinstance(o, dict):
            for k, v in o.items():
                kl = k.lower()
                if any(b in kl for b in banned) and kl not in ("approval_status",):
                    rep.err(f"{path}{k}",
                            "policy-verdict field: this schema records facts only")
                scan(v, f"{path}{k}.")
    scan(obj)


def validate(obj, index=None):
    rep = Report()
    prefix = "" if index is None else f"[{index}]."
    if not isinstance(obj, dict):
        rep.err(prefix.rstrip("."), "expected a JSON object per receipt")
        return rep
    if obj.get("schema_version") != SCHEMA_VERSION:
        rep.err(prefix + "schema_version",
                f"expected {SCHEMA_VERSION!r}, got {obj.get('schema_version')!r}")
    for name, spec in SPEC.items():
        if name not in obj:
            rep.err(prefix + name, "missing block")
            continue
        check_block(rep, name, obj[name], spec)
    if "line_items" not in obj:
        rep.err(prefix + "line_items", "missing block")
    for key in obj:
        if key not in SPEC and key not in ("schema_version", "line_items"):
            rep.warn(prefix + key, "unknown top-level key (not in schema v1.0)")

    check_formats(rep, obj)
    check_taxes(rep, obj)
    check_line_items(rep, obj)
    check_derived(rep, obj)
    check_reconciliation(rep, obj)
    check_cross_field(rep, obj)

    if prefix:
        for lst in (rep.errors, rep.warnings):
            for e in lst:
                e["path"] = prefix + e["path"]
    return rep


def main():
    ap = argparse.ArgumentParser(description="Validate receipt extraction JSON (v1.0)")
    ap.add_argument("path", help="JSON file (one receipt object or an array of them)")
    ap.add_argument("--quiet", action="store_true", help="print problems only")
    ap.add_argument("--json", action="store_true", dest="as_json",
                    help="emit a machine-readable report")
    args = ap.parse_args()

    try:
        with open(args.path, encoding="utf-8") as fh:
            data = json.load(fh)
    except FileNotFoundError:
        print(f"ERROR: file not found: {args.path}", file=sys.stderr)
        return 2
    except json.JSONDecodeError as exc:
        print(f"ERROR: invalid JSON in {args.path}: {exc}", file=sys.stderr)
        return 2

    objs = data if isinstance(data, list) else [data]
    errors, warnings = [], []
    for i, obj in enumerate(objs):
        rep = validate(obj, index=i if isinstance(data, list) else None)
        errors += rep.errors
        warnings += rep.warnings

    if args.as_json:
        print(json.dumps({"file": args.path, "receipts": len(objs),
                          "valid": not errors, "errors": errors,
                          "warnings": warnings}, indent=2))
        return 0 if not errors else 1

    if errors:
        print(f"FAIL  {args.path}  ({len(errors)} error(s), {len(warnings)} warning(s))")
        for e in errors:
            print(f"  ERROR  {e['path']}: {e['message']}")
    elif not args.quiet:
        print(f"PASS  {args.path}  ({len(objs)} receipt(s), "
              f"{len(warnings)} warning(s))")
    if warnings and (errors or not args.quiet):
        for w in warnings:
            print(f"  WARN   {w['path']}: {w['message']}")
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
