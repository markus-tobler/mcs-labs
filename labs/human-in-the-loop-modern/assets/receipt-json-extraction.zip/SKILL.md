---
name: receipt-json-extraction
description: Extract a receipt, invoice, or bill into a single structured, policy-checkable JSON document. Use this skill whenever a user uploads or points to a receipt, invoice, till slip, restaurant bill, hotel folio, taxi ticket, or expense photo/PDF/scan and wants the data pulled out — including phrasings like "digitise this receipt", "extract the line items", "turn this invoice into JSON", "prepare this for expense submission", "get the totals and VAT out of this", or "parse this bill so we can run it through our expense rules". It also applies when an expense or approval workflow needs machine-readable receipt data as its input. The skill only extracts and normalises what the document shows; it never judges compliance, eligibility, or approval.
license: Proprietary. Provided for internal use.
---

# Receipt → policy-checkable JSON

## What this skill is for

Downstream systems (expense policies, approval flows, audit tooling) can only make
decisions if the receipt has been turned into faithful, predictable, machine-readable
data. That's the whole job here: read the document, emit one JSON object that follows
the schema in `references/schema.md`, and stop there.

**Extraction only.** Do not decide whether an expense is allowed, within a limit,
reimbursable, suspicious, or in need of approval, and do not add fields like
`policy_violation`, `approved`, `compliant`, or `risk_score`. Policies change per
company and per year; a verdict baked into the extraction would silently rot and would
also hide the evidence a reviewer needs. Your value is neutral, complete evidence —
someone else applies the rules.

That said, extract the *facts policies tend to depend on* even when they seem minor:
guest counts, alcohol lines, purchase-order numbers, transaction dates, currency,
exchange rates, tax and tip split, payment method, itemisation. A missing guest count
or PO number is the difference between a checkable claim and an unusable one.

## Workflow

1. **Read the document at full fidelity.**
   - Images (`.png`, `.jpg`, `.heic`, …): view the image directly. If text is small or
     dense, crop/zoom rather than guessing. Never OCR by intuition.
   - PDFs: preprocess with the available PDF analysis skill/tooling and read the
     extracted text; render the page as an image when the text layer is empty, garbled,
     or the layout matters (multi-column bills, stamped notes).
   - Multi-page or multi-receipt inputs: emit **one JSON object per receipt**. If a
     single file holds several receipts, return a JSON array of receipt objects.

2. **Transcribe before you interpret.** Note the raw strings for money, dates, and
   totals as printed. Several schema fields exist specifically to hold the raw form
   (`*_raw`), because a reviewer needs to see what the paper actually said when a
   normalised value looks odd.

3. **Fill the schema** in `references/schema.md`, top to bottom. Read that file before
   your first extraction in a session — it defines every field, its type, and the
   normalisation rules. Unknown values are `null`; empty collections are `[]`.

4. **Compute only the deterministic derivations** the schema asks for (`derived`
   block): alcohol subtotal, alcohol share of total, per-person amount, item count.
   These are arithmetic on extracted numbers, not judgements — they exist because
   policies phrase limits per person or as a percentage cap, and recomputing them
   downstream from free text is error-prone. Anything that requires a threshold or a
   rule stays out.

5. **Validate before you answer:**
   ```bash
   python scripts/validate_receipt_json.py <output.json>
   ```
   It is stdlib-only (no installs) and checks structure, types, enums, ISO date/time
   formats, and arithmetic consistency (line items vs subtotal, subtotal + tax + tip
   vs total, alcohol share, per-person amount). Fix what it reports and re-run until
   it passes. `--quiet` prints only failures; `--json` emits a machine-readable report.

6. **Deliver** the JSON file (and a short plain-language summary of what was on the
   receipt plus anything you could not read). Save the artifact where the user expects
   deliverables.

## Rules that keep the output trustworthy

**Never invent.** If a field is not on the document, it is `null` — not a plausible
guess, not a default of `0`. `0` means "printed as zero"; `null` means "not stated".
A fabricated PO number or attendee list can push a false claim through an approval
flow, which is the worst failure mode this skill has.

**Uncertainty is data.** When a glyph is ambiguous (`€57.78` vs `€5778`, `0` vs `8`),
record your best reading, drop the field name into
`extraction.fields_low_confidence`, and describe the ambiguity in
`extraction.warnings`. Reviewers can act on flagged uncertainty; they cannot act on
silent errors.

**Preserve contradictions instead of repairing them.** Receipts really do print
`TIME: INVALID DATE`, totals that don't add up, or a tax line that doesn't match the
rate. Put the printed value in the raw field, set the normalised field to `null` when
it isn't parseable, set `amounts.totals_reconcile` to `false` with a note, and warn.
Quietly "fixing" arithmetic destroys the very anomaly an auditor is looking for.

**Money is numeric, currency is separate.** Amounts are JSON numbers (`57.78`), never
strings and never with symbols. `amounts.currency` is a single ISO-4217 code for the
document. Watch decimal conventions: `1.234,56` in continental formats is `1234.56`.
If the currency symbol is genuinely absent, infer from country/language cues only,
set `currency_inferred` to `true`, and say why in a warning.

**Dates are ISO or nothing.** `date` is `YYYY-MM-DD`, `time` is `HH:MM` (24h),
`datetime_iso` combines them when both exist. Keep the printed string in `date_raw`.
`16.9.2026` is day-first (16 September 2026); when day/month order is truly ambiguous
(e.g. `03/04/2026` with no other clue), pick the reading suggested by the merchant's
country, set `date_is_ambiguous` to `true`, and warn. Expense policies run on
deadlines, so a swapped date silently changes the outcome.

**Line items carry the flags policies need.** For each line set `category_hint`
(what kind of purchase it is) and `is_alcohol` (best-effort: wine, beer, spirits,
champagne, cocktails, aperitifs). These are descriptive labels, not verdicts — a rule
about alcohol caps or personal items can't be evaluated if the items are an
undifferentiated blob of strings. When a line's nature is genuinely unclear, use
`"unknown"` rather than forcing a category.

**Keep quantity and unit price honest.** `2 CAESAR SALAD @ €12.00 … €24.00` is
`quantity: 2`, `unit_price: 12.00`, `line_total: 24.00`. When only a line total is
printed, `quantity` defaults to `1` and `unit_price` is `null` unless it is derivable
exactly.

**One document, one object.** Don't merge a receipt with its credit-card slip or a
hotel folio with the restaurant bill inside it — emit separate objects and link them
via `document.related_documents` if needed.

## Worked example (abridged)

Input: a restaurant till slip printing `2 CAESAR SALAD @ €12.00 → €24.00`,
`GRILLED SALMON → €22.00`, `CHEESECAKE → €7.50`, `SUBTOTAL €53.50`, `TAX €4.28`,
`TOTAL €57.78`, `GUESTS: 2`, `TIME: INVALID DATE` in the card block, dated
`16.9.2026 20:15`.

Key parts of the output:

```json
{
  "transaction": {
    "date": "2026-09-16", "date_raw": "16.9.2026", "time": "20:15",
    "datetime_iso": "2026-09-16T20:15", "guest_count": 2
  },
  "amounts": {
    "currency": "EUR", "subtotal": 53.50, "tax_total": 4.28,
    "tip": null, "total": 57.78, "totals_reconcile": true
  },
  "line_items": [
    { "line_number": 1, "description": "2 CAESAR SALAD @ €12.00",
      "description_normalized": "Caesar salad", "quantity": 2,
      "unit_price": 12.00, "line_total": 24.00,
      "category_hint": "food_beverage", "is_alcohol": false }
  ],
  "derived": {
    "item_count": 3, "alcohol_total": 0.0,
    "alcohol_share_of_total_percent": 0.0, "amount_per_person": 28.89
  },
  "extraction": {
    "warnings": ["Card block prints 'TIME: INVALID DATE'; transaction time taken from the header timestamp 20:15."]
  }
}
```

Note what did *not* happen: no statement about whether €57.78 for two guests is
within anyone's meal limit, and no repair of the odd `INVALID DATE` string — it was
recorded as a warning so a human can see it.

## Files in this skill

- `references/schema.md` — the full field-by-field schema and normalisation rules.
  Read it before extracting; it is the contract the validator enforces.
- `scripts/validate_receipt_json.py` — stdlib-only structural + arithmetic validator.
- `assets/example_receipt.json` — a complete, valid reference output covering the
  tricky cases (alcohol lines, guest counts, unreconciled totals, foreign currency).
